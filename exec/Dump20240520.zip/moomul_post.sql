CREATE DATABASE  IF NOT EXISTS `moomul` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `moomul`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: moomul.kr    Database: moomul
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `reply` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `post_type` enum('TO_ME','FROM_ME') DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,'나였으면 못고른다','hi',NULL,1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(2,'나였으면 못고른다','hi',NULL,1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(3,'나였으면 못고른다','hi',NULL,1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(4,'나였으면 못고른다','hi',NULL,1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(5,'나였으면 못고른다','hi',NULL,1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(6,'나였으면 못고른다','hi',NULL,1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(7,'나였으면 못고른다','hi','test',1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(8,'나였으면 못고른다','hi','test',1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(9,'나였으면 못고른다','hi','test',1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(10,'나였으면 못고른다','hi','test',1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(11,'나였으면 못고른다','hi','test',1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(12,'나였으면 못고른다','hi','test',1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(13,'나였으면 못고른다','hi','test',1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(14,'나였으면 못고른다','hi','test',1,'TO_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(15,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(16,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(17,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(18,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(19,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(20,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(21,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(22,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(23,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(24,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(25,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(26,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(27,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(28,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(29,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(30,'나였으면 못고른다','hi',NULL,1,'FROM_ME',_binary '\0','2024-05-07 08:24:27','2024-05-07 08:24:27'),(31,'나였으면 못고른다44','작성자 닉네임44',NULL,1,'FROM_ME',_binary '\0','2024-05-09 04:47:23','2024-05-09 04:47:23'),(32,'나였으면 못고른다','작성자 닉네임','굿굿',1,'TO_ME',_binary '\0','2024-05-09 04:48:23','2024-05-20 00:21:32'),(33,'오늘 저녁 모머글랭?','이바보야진짜','1234',1,'TO_ME',_binary '\0','2024-05-09 07:16:52','2024-05-20 00:19:07'),(34,'오잉?',NULL,NULL,1,'FROM_ME',_binary '\0','2024-05-13 06:41:18','2024-05-13 06:41:18'),(35,'오잉?',NULL,NULL,1,'FROM_ME',_binary '\0','2024-05-13 06:41:18','2024-05-13 06:41:18'),(36,'오잉?',NULL,NULL,1,'FROM_ME',_binary '\0','2024-05-13 06:41:18','2024-05-13 06:41:18'),(37,'오잉?',NULL,NULL,1,'FROM_ME',_binary '\0','2024-05-13 06:41:18','2024-05-13 06:41:18'),(38,'오늘모하뉘','hahaha','1234',1,'TO_ME',_binary '\0','2024-05-17 14:08:58','2024-05-20 00:18:55'),(39,'오늘모하뉘','hahaha','123412341234',1,'TO_ME',_binary '\0','2024-05-17 15:00:39','2024-05-20 00:17:46'),(40,'',NULL,NULL,40,'FROM_ME',_binary '\0','2024-05-18 06:23:17','2024-05-18 06:23:17'),(41,'모해?',NULL,NULL,40,'FROM_ME',_binary '\0','2024-05-18 06:24:07','2024-05-18 06:24:07'),(42,'??','?','1234',1,'TO_ME',_binary '\0','2024-05-18 06:47:48','2024-05-20 00:17:15'),(43,'q','q','1234',1,'TO_ME',_binary '\0','2024-05-18 06:48:47','2024-05-20 00:16:25'),(44,'??','나야나','ffff',1,'TO_ME',_binary '\0','2024-05-18 06:49:27','2024-05-20 00:15:15'),(45,'피자가 좋아요 치킨이 좋아요',NULL,NULL,4,'FROM_ME',_binary '\0','2024-05-18 15:21:08','2024-05-18 15:21:08'),(46,'콜라vs사이다','나나나',NULL,4,'TO_ME',_binary '\0','2024-05-18 15:21:49','2024-05-18 15:21:49'),(47,'안녕',NULL,NULL,36,'FROM_ME',_binary '\0','2024-05-18 17:34:06','2024-05-18 17:34:06'),(48,'hi',NULL,NULL,43,'FROM_ME',_binary '\0','2024-05-19 07:42:43','2024-05-19 07:42:43'),(49,'안녕',NULL,NULL,42,'FROM_ME',_binary '\0','2024-05-19 07:48:19','2024-05-19 07:48:19'),(50,'',NULL,NULL,1,'FROM_ME',_binary '\0','2024-05-19 08:21:47','2024-05-19 08:21:47'),(51,'',NULL,NULL,1,'FROM_ME',_binary '\0','2024-05-19 08:24:50','2024-05-19 08:24:50'),(52,'나 누구게',NULL,NULL,1,'FROM_ME',_binary '\0','2024-05-19 08:59:58','2024-05-19 08:59:58'),(53,'뭐먹을래',NULL,NULL,42,'FROM_ME',_binary '\0','2024-05-19 09:04:48','2024-05-19 09:04:48'),(54,'',NULL,NULL,43,'FROM_ME',_binary '\0','2024-05-19 09:12:23','2024-05-19 09:12:23'),(55,'유머 감각을 기르려면 어떻게 해야 할까용?',NULL,NULL,44,'FROM_ME',_binary '\0','2024-05-19 12:37:22','2024-05-19 12:37:22'),(56,'바보','','fff',1,'TO_ME',_binary '\0','2024-05-19 12:37:49','2024-05-20 00:14:52'),(57,'싸피 가기싫어 너두?',NULL,NULL,43,'FROM_ME',_binary '\0','2024-05-19 12:38:02','2024-05-19 12:38:02'),(58,'jihi','hi','바보바보',1,'TO_ME',_binary '\0','2024-05-19 12:38:02','2024-05-20 00:13:54'),(59,'이거 한번해봐','','ㅂ',1,'TO_ME',_binary '\0','2024-05-19 12:38:09','2024-05-20 00:13:42'),(60,'잠은 잘 주무셨나용?','who','',1,'TO_ME',_binary '\0','2024-05-19 12:38:23','2024-05-20 00:08:50'),(61,'','test',NULL,43,'TO_ME',_binary '\0','2024-05-19 12:38:24','2024-05-19 12:38:24'),(62,'안녕?','','',1,'TO_ME',_binary '\0','2024-05-19 12:39:22','2024-05-20 00:02:11'),(63,'안녕?','','fff',1,'TO_ME',_binary '\0','2024-05-19 12:39:22','2024-05-20 00:15:59'),(64,'','골라',NULL,36,'TO_ME',_binary '\0','2024-05-19 23:32:59','2024-05-19 23:32:59'),(65,'aafafa','ah','qwer',1,'TO_ME',_binary '\0','2024-05-20 00:19:31','2024-05-20 00:19:52'),(66,'asdfa','asdf','1234',1,'TO_ME',_binary '\0','2024-05-20 00:20:43','2024-05-20 00:21:02'),(67,'점심은 모닝?',NULL,NULL,50,'FROM_ME',_binary '\0','2024-05-20 01:06:40','2024-05-20 01:06:40'),(68,'ㅎㅎㅎㅎ','내가 누구게~',NULL,50,'TO_ME',_binary '\0','2024-05-20 01:08:01','2024-05-20 01:08:01'),(69,'ㄹㄹ','ㄹㄹ',NULL,50,'TO_ME',_binary '\0','2024-05-20 01:08:22','2024-05-20 01:08:22');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-20 10:09:01
